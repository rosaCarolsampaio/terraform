exports.handler = async function(event, context) {
  console.log("ENVIRONMENT VARIABLES\n")
  console.log("EVENT\n" )
  return context.logStreamName
}